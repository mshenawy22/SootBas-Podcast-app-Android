package com.sootbas.sootbasapp.event;


public class BaseEvent {
}
